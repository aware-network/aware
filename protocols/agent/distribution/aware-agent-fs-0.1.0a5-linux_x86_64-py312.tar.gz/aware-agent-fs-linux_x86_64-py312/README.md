# Aware agent filesystem preview

Linux x86-64 / Python 3.12.
Verify SHA256SUMS before use. Sources and component notices accompany the wheels.
Install offline into a new venv: python3.12 -m venv /absolute/new-venv; /absolute/new-venv/bin/python -m pip install --no-index --find-links wheelhouse aware-agent-cli==0.1.0a5
Consumer entrypoint: aware. Setup installs a versioned agent contract and modules. No service, ontology, generated API or development checkout.
