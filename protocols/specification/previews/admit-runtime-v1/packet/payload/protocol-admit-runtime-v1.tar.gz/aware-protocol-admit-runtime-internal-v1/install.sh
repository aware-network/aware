#!/bin/sh
set -eu
PYTHON_BIN="${PYTHON_BIN:-python3}"
TARGET_VENV="${1:-.aware-portable-venv}"
actual_minor="$($PYTHON_BIN -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
test "$actual_minor" = "3.12" || { echo "python_minor_mismatch:3.12:$actual_minor" >&2; exit 2; }
"$PYTHON_BIN" -m venv "$TARGET_VENV"
"$TARGET_VENV/bin/python" -m pip install --no-index --find-links "$(dirname "$0")/wheelhouse" aware-protocol-cli[specification-setup]==0.3.1 aware-specification-cli==0.2.0
"$TARGET_VENV/bin/aware-protocol" --help >/dev/null
"$TARGET_VENV/bin/aware-spec" --help >/dev/null
