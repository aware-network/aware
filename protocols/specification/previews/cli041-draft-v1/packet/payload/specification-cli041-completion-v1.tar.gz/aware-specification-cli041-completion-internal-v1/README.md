# Internal SPEC 0.4.1 completion qualification candidate

Not a selected customer release. Python 3.12 / Linux x86_64.

Verify SHA256SUMS, then use PYTHON_BIN=/usr/bin/python3.12 ./install.sh /absolute/new/environment.
Only aware-spec is exposed. Use the separately installed accepted setup CLI; never overlay environments.
The governed extra is selected; exit 0 requires original correlated whole-context completion.
Late refusals may retain known publication with exit 2; never automatically retry known publication.
No approved iterations, Goal writers, Service/API, every-write detection or continuous confinement are admitted.
Public notice/content review, consumer acceptance, selection and publication remain held.
