# Aware Protocol filesystem client distribution

Source revision: `b6bcae3c4a54295f4174f69eae507e242f9e4794`
Authority mode: `filesystem`
Protocol profile: `aware.collaboration.fs_v1`
Target: `linux_x86_64` / Python `3.12`

Install into a fresh environment:

```bash
./install.sh /absolute/path/to/new-venv
```

Verify `SHA256SUMS` before installation. This bundle exposes filesystem
operations only. It contains no Service/API authority, credentials, Aware
development checkout, editable package, or `PYTHONPATH` dependency.

Internal setup/read qualification candidate, not a customer release.
Setup uses the installed typed optional composition; no setup CLI
or governed SPEC draft writer is supplied. Existing qualified SPEC
documents/iterations are separately supplied test input.
Currentness means exact observed state under cooperative filesystem
topology; it is not detection of every intervening write. Equal-byte
same-inode rewrites can be unobservable. Every-write detection and
continuous confinement are unsupported by this profile.
