# Third-party and package notices

The nested payload has 13 wheels. The files under `notices/wheels/` are exact copies of their in-wheel legal files; the wheel byte hashes and source members are mapped in `manifest.json`.

`notices/json-schema/` adds the complete specification-resource attribution, the selected BSD-3-Clause upstream text (the complete upstream file also contains AFL-3.0), and the wheel's MIT text. Its index is bound to this payload.

`notices/rpds/` carries the conservative Cargo-source and Rust 1.96 legal texts with their source-qualified map. The map does not assert that every listed crate or Fuchsia-specific source was linked into the Linux binary.

| Distribution | Version | Origin | In-wheel legal files |
| --- | --- | --- | ---: |
| `attrs` | `26.1.0` | `registry` | 1 |
| `aware-goal-native-cli` | `0.1.0` | `aware_source` | 2 |
| `aware-goal-native-fs-adapter` | `0.1.0` | `aware_source` | 2 |
| `aware-goal-operational-runtime` | `0.1.0` | `aware_source` | 2 |
| `aware-goal-sdk` | `0.3.0` | `aware_source` | 2 |
| `aware-protocol-fs-adapter` | `0.2.0` | `aware_source` | 2 |
| `aware-protocol-runtime` | `0.1.0` | `aware_source` | 2 |
| `aware-protocol-sdk` | `0.1.0` | `aware_source` | 2 |
| `jsonschema` | `4.26.0+aware.1` | `source_derived` | 2 |
| `jsonschema-specifications` | `2025.9.1` | `registry` | 1 |
| `referencing` | `0.37.0` | `registry` | 1 |
| `rpds-py` | `2026.6.3` | `registry` | 1 |
| `typing-extensions` | `4.15.0` | `registry` | 1 |
