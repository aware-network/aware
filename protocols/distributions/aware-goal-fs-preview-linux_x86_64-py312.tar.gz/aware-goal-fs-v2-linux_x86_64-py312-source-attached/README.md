# Aware Goal filesystem client

Target: Linux x86-64, Python 3.12. Authority mode: filesystem. Protocol profile:
`aware.collaboration.fs_v2`. The supported native command is `aware-goal-native`.

## Install

From this envelope's top-level directory, run `sha256sum -c SHA256SUMS`.
Extract the nested archive in `payload/`, enter its single top-level directory,
and run its own `sha256sum -c SHA256SUMS`. Then install into a new virtual
environment with its `install.sh`, selecting Python 3.12 explicitly, for example:

```sh
PYTHON_BIN=/usr/bin/python3.12 ./install.sh /absolute/path/to/new-venv
```

The example interpreter path is illustrative; select the actual supported
Python 3.12 executable on your host. No Aware development checkout, editable
install, service or inherited `PYTHONPATH` is needed.


The nested archive's exact top-level directory is `aware-neutral-native-goal-readonly-fs-v2-cb-test-3bea9cc91364-linux_x86_64-py312`. Its
`cb-test` suffix is a retained internal-candidate label, not a Protocol version
or an alternate authority mode. Verify its checksum before installation; do
not rename or edit the inner archive to hide that label.

## Source attachment

`sources/aware-goal-fs-source-capsule-v2.tar.gz` carries the exact Aware wheel-matched source files, package
build/legal inputs and the source-derived `jsonschema` recipe. Verify the
capsule hash from this envelope's manifest, then its own `SHA256SUMS`. The
capsule is a source-transparency attachment, not proof of a reproducible build
or a separate installed interface.

## Qualified-input limitation

This installed cut does not create/import a V2/V3 Goal or set up a customer's
manifest. A preparation owner must provide a provenance-qualified committed
Goal, an explicitly selected `aware.protocol.toml`, and exact approved
Goal/Lane/Phase coordinates. Do not manually edit authoritative Goal/Issue
records to manufacture eligibility. Without those inputs, the read-only
commands cannot provide a self-serve collaboration workflow. Eligibility and
direction never grant approval, pursuit, dispatch or publication authority.

## Read-only native Goal observations

Bring a Git repository with an explicitly selected `aware.protocol.toml`, a
provenance-qualified committed Goal, and exact approved Goal path/tag plus
Lane and Phase keys. The record profile `aware.goal.phase.markdown.v1` carries
strict V2/V3 Phase documents. Legacy lane-row records and native document V1
do not silently substitute.

Given those exact inputs, the supported command forms are:

```text
aware-goal-native --repository-root <repo> --manifest-path <repo>/aware.protocol.toml \
  --discover-goal-path <repo-relative-goal-path> --lane-key <lane> --phase-key <phase>

aware-goal-native --repository-root <repo> --manifest-path <repo>/aware.protocol.toml \
  --request-file <exact-discovery-output.json> \
  [--prerequisite-goal <goal-tag>=<repo-relative-prerequisite-path>]

aware-goal-native observe_phase_direction \
  --repository-root <repo> --manifest-path <repo>/aware.protocol.toml \
  --goal-path <repo-relative-goal-path> --goal-tag <goal-tag> \
  --lane-key <lane> --phase-key <phase>

aware-goal-native verify_phase_direction_currentness \
  --repository-root <repo> --manifest-path <repo>/aware.protocol.toml \
  --goal-path <repo-relative-goal-path> --receipt-file <exact-direction-output.json>
```

Save discovery's exact JSON bytes as the observation request; do not rebuild
Gate or document identity from a path. Supply prerequisite hints only for
explicitly approved cross-Goal sources. Retain actual result and direction
receipts outside authoritative Goal/Issue records. A held result, stale receipt
or refusal is evidence to report, not a record to patch into success.

These operations do not create or edit a Goal, accept a Gate, admit pursuit,
dispatch work, or open/claim/close an Issue. A positive eligibility result or
`current` direction receipt grants no work or publication authority. Current-
epoch rejection is unsupported. Service/API authority and ActorWorld are not
included, and service failure cannot turn a service-owned projection into
filesystem-owned truth.

`THIRD-PARTY-NOTICES.md` locates package legal files and additional scoped
JSON Schema and `rpds` component notices.
