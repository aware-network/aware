# Internal canonical neutral FS candidate

Single producer profile: portable_protocols. Python 3.12 / Linux x86_64.

Verify SHA256SUMS, then use PYTHON_BIN=/usr/bin/python3.12 ./install.sh /absolute/fresh/environment in an existing private parent.

Supported family commands: aware-issue-cli, aware-protocol, aware-spec. No unified aware entrance is supplied.

Issue publication, SPEC setup and governed draft/read composition require candidate-bound installed qualification. No Goal writers, approved iterations, Service/API, every-write detection or continuous confinement.

Full discovery inventory is producer-only. Public source/notice/content acceptance, consumer freeze, selection and publication remain held.
