#!/bin/sh
set -eu
test "$#" = 1 || { echo 'fresh_absolute_environment_required' >&2; exit 2; }
PYTHON_BIN="${PYTHON_BIN:-python3.12}"
TARGET_VENV="$1"
case "$TARGET_VENV" in /*) ;; *) echo 'absolute_environment_required' >&2; exit 2;; esac
test ! -e "$TARGET_VENV" || { echo 'environment_already_exists' >&2; exit 2; }
test ! -L "$TARGET_VENV" || { echo 'environment_symlink_refused' >&2; exit 2; }
test -d "$(dirname "$TARGET_VENV")" || { echo 'environment_parent_missing' >&2; exit 2; }
actual_minor="$($PYTHON_BIN -I -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
test "$actual_minor" = 3.12 || { echo 'python_minor_mismatch:3.12' >&2; exit 2; }
"$PYTHON_BIN" -I -c 'import platform; assert platform.system()=="Linux" and platform.machine()=="x86_64"'
bundle_root="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
(cd "$bundle_root" && sha256sum --strict -c SHA256SUMS >/dev/null)
"$PYTHON_BIN" -I -m venv "$TARGET_VENV"
"$TARGET_VENV/bin/python" -I -m pip --isolated install --no-cache-dir --no-index --only-binary=:all: --require-hashes --find-links "$bundle_root/wheelhouse" -r "$bundle_root/requirements.lock.txt"
"$TARGET_VENV/bin/python" -I -m pip --isolated check
"$TARGET_VENV/bin/aware-issue-cli" --help >/dev/null
"$TARGET_VENV/bin/aware-protocol" --help >/dev/null
"$TARGET_VENV/bin/aware-spec" --help >/dev/null
