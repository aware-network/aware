# Aware Issue observations for reviewed customer work

Draft technical-review instructions for the exact Linux x86-64 / Python 3.12
candidate `f5e65fefa12ac6a778bf39e7efdffacf3a8a8b1fb261a6332a9656388ab94b5a`.
Agent **0.2.0a14** composes Workspace SDK **0.2.13**, Runtime **0.2.18** and FS
adapter **0.1.11**, with Protocol FS **0.6.6**, FileSystem **0.3.8**,
Issue SDK **0.10.6**, Issue FS **0.9.6** and Issue CLI **0.8.4**.
The canonical `portable_protocols` profile selects 28 Aware packages, with a
42-package installed dependency closure. This envelope
adds complete source/notice carriage and guidance, not new software or authority.

The bounded installed proof additionally covers explicit Issue observation input,
original publication/closeout and refusals. It covers two-review repository-manifest A1 and its
affected refusal/evidence joins. It does not qualify broader carried features,
the historical aggregate matrix, Project/Goal workflows, A2, tree completion,
parser lowering or unassisted onboarding. Exact-envelope notice/disclosure
decisions, instruction freeze, selection and publication remain separate.

The qualified entrance remains default Issue-first init, then an admitted Issue
and separately reviewed work. The optional Goal registrar is not selected.
Positive `--profile create-first` execution is unqualified; do not treat its
presence in help as an available Project/Goal onboarding workflow.

## Install and retain the whole envelope

Retain this complete envelope alongside the installation. Verify outer
`SHA256SUMS`, expand `payload/aware-canonical-neutral-fs-internal-v1.tar.gz`
into a fresh private directory, and verify its inner `SHA256SUMS`. Enter that
inner directory before running the shipped installer. Keep LICENSE, NOTICE,
`source/THIRD_PARTY_NOTICES.md`, corresponding sources, all notices, component
evidence and indexes. Detached wheels, stripped bundles and registry publication
are not accepted. Choose an absent environment beneath an existing private parent:

```bash
set -eu
: "${aware_review_env:?Set an absolute absent environment under a private parent}"
test ! -e "$aware_review_env"
test ! -L "$aware_review_env"
PYTHON_BIN=/usr/bin/python3.12 /bin/sh ./install.sh "$aware_review_env"
AWARE="$aware_review_env/bin/aware"
"$AWARE" --help
"$AWARE" init --help
"$AWARE" workspace review --help
```

Tool installation, repository/configuration preparation, Issue admission,
scope acceptance and operation application are distinct. Init previews by
default; explicit creation/apply uses Workspace preparation then fresh Protocol
bootstrap admission. A new-repository preview has a Workspace preparation
preview and prospective Protocol inputs, not two admitted owner plans.
Init supplies the Protocol configuration used by this qualified fresh-repository
workflow. It does not admit an Issue, approve scope or authorize Workspace apply.
It does not stage files, commit or select a remote. The admitted fresh-repository
journey uses init-created `aware.protocol.toml` without another configuration step.
If owner configuration or Issue inputs are missing, stop rather than fabricate
them or bypass admission.

## Read init summaries and preserve full receipts

Init keeps its default JSON output. Select `--format summary` explicitly for
human-readable answers: **What happened**, **What changed**,
**What remains uncertain**, **What next (guidance, not authority)** and
**Where is full evidence**. The full `aware.agent.init.v1` JSON is emitted on
**stderr in the same invocation**, while the summary is on stdout. Explicit
`--format json` retains the same transport as default JSON: full JSON on
stdout. Stderr is not an error-only channel when summary format is selected.

Choose the customer repository explicitly; do not initialize the acquired
public source checkout. For an absent intended target, preview first:

```bash
: "${aware_customer_repo:?Set the absolute intended customer repository}"
"$AWARE" init --repo-root "$aware_customer_repo" --create-repository --format summary
```

Stop and review that preview and its complete JSON before making a separate
creation decision. A new-repository preview has no effects, verified completion
or admitted Protocol plan; it reports prospective Protocol inputs. Creation
requires explicit intent. Only after accepting that request, invoke:

```bash
"$AWARE" init --repo-root "$aware_customer_repo" --create-repository --apply --format summary
```

Do not blindly execute both blocks as an unattended sequence. Apply obtains
fresh Protocol admission after Workspace preparation; a preview is not a
reusable admission. Both original owner receipts remain available in full.
An existing repository or missing explicit creation intent has its own original
owner outcome; do not infer creation from presentation alone.

If retaining command output, capture both streams during the original invocation
to distinct, newly chosen files. Do not repeat a mutating command to obtain
JSON or a better summary. Full output may describe known effects, partial
publication, refused work or original cleanup uncertainty. Summary omission
does not erase that evidence and does not restore authority.

Output failure returns **3**, or preserves **130** for an existing interruption.
Either may coexist with already completed owner effects. The surviving stream
still carries available evidence; the process does not redispatch either owner.
Do not retry merely because a stream was lost. Stop and inspect retained
evidence before any separately supported recovery decision. The source-qualified
and installed closed-pipe checks do not imply a saved receipt exists when no
capture or durable reference was returned.

## Keep the public checkout and customer target distinct

The acquired public source checkout's contributor `AGENTS.md` and separately
pinned a6 selection govern contributions there. They are not your customer
bootstrap or a fallback command selection. In the explicitly chosen customer
target, read its init-created `AGENTS.md` and `aware.protocol.toml`; use the one
consumer installation's original Issue, Protocol and SPEC registrars. Do not
copy source-checkout instructions into the target, replace either selection,
or infer that a contributor composition such as `aware issue open` exists in
the installed product. Follow its first-Issue instructions and installed help.

This technical envelope does not select a public revision or activate the
entrance/router proposal. Public instructions and revision pins require the
later governed layout and instruction review.
Historical source READMEs are not alternative customer instructions. The inner
payload README is retained legacy builder text, including pre-init wording.
For this candidate, this outer guide supersedes that inner README on installed
capabilities and workflow; do not follow its obsolete no-init statements.

## Prepare, review physical scope, then review final files

The current reviewed command creates a repository manifest. It requires an
explicit repository, admitted Issue reference and exact Issue Markdown path,
existing Protocol configuration, declared actor/evidence coordinates, chosen
repository name/license expression, and a unique explicit client intent.
An Issue reference is not its Markdown path. Preserve the original SDK values;
do not parse a diagnostic string into a guard or invent missing coordinates.

The private evidence root must already exist outside and disjoint from the
repository. Do not use a shared evidence root, handwrite records or synthesize
SDK references. Inspect the supported entrances:

```bash
"$AWARE" workspace review prepare --help
"$AWARE" workspace review show --help
"$AWARE" workspace review scope --help
"$AWARE" workspace review apply --help
"$AWARE" workspace review evidence --help
```

1. Invoke `review prepare` with the explicit owner inputs. Review the first
   result: repository/Issue/authority source, manifest target, complete physical
   effect scope, proposed final files and cleanup. Preparation gives **no setup
   write admission** and makes no Issue scope change. Complete physical scope
   includes temporary effects; it is not the final-file set.
2. Only after accepting that scope invoke `review scope` with
   `--accept-reviewed-effect-scope`, the exact first SDK-issued reference and
   a distinct client intent. The original Issue SDK binds scope while preserving
   existing work. The original Workspace SDK retains that outcome and produces
   a second preview. Stop and review the second preview's final files separately;
   scope acceptance is not consent to automatic apply.
3. Only after this second decision invoke `review apply` with
   `--accept-reviewed-final-files`, the exact second SDK-issued reference and
   its own explicit client intent. Keep the reviewed repository/evidence roots
   and original guards unchanged. No guard copying, record writer, reconstructed
   allowlist, automatic refresh or mutation retry is provided.

`--reference` takes the complete opaque SDK-issued `SetupEvidenceRef` JSON value,
not a filename. Reuse the returned value exactly; do not author fields, execute
JSON vectors or use `eval`. Use `show --json` for a full owner record when the
human summary omits a long set. Retain both references and original evidence
for handoff; a different execution still needs lawful transfer/admission.

Stale, spent, malformed and foreign requests stop. Prepare and review again
only after an explicit new decision; never silently refresh or retry. Reading
historical records grants no current-use authority. Scope success followed by
second-preview failure stays scope success with a later failure, not rollback.
Preserve that original outcome.

## Carry an original result explicitly through stdin

Workspace review now accepts `--reference-from-stdin` instead of `--reference`.
Supply exactly one complete UTF-8 JSON result captured from the original Agent
command, with `contract=aware.agent.workspace-review.v1` and its original
top-level `/reference`. The client delegates reference decoding and all live-use
checks to the original SDK. A nested reference, diagnostic string or a filename
inside JSON is not an alternative selector. The two flags are mutually exclusive.
Legacy inline `--reference` behavior is unchanged.

An input frame's `status`, apparent completion or human prose grants no authority.
The frame must reach EOF. Input is bounded to 2 MiB, 64 container levels and
65,536 nodes; malformed UTF-8/JSON, duplicate keys, non-finite values, interactive
or unavailable stdin and missing top-level references refuse. If the producer
does not close its stream, no automatic timeout or mutation retry is promised;
interrupt deliberately and retain the partial-input evidence. Exit 130 preserves
interruption and does not mean the SDK acquired or dispatched an operation.

Capture each original JSON result during its original invocation into a newly
chosen private file. Do not repeat a mutating command to recover its output.
Select all repository/evidence/result paths explicitly; never point this flow at
the acquired public contributor checkout. Historical inspection can focus a
complete selected list without copying a long reference:

```bash
: "${aware_customer_repo:?Set the customer repository}"
: "${aware_evidence_root:?Set the existing private disjoint evidence root}"
: "${aware_first_result:?Set the complete original prepare-result JSON file}"
"$AWARE" workspace review show --repository-root "$aware_customer_repo" --evidence-root "$aware_evidence_root" --reference-from-stdin --focus scope < "$aware_first_result"
```

`show --focus overview|scope|files|guards` is historical review only, with **no
current-use authority**. It preserves original release uncertainty and client
cleanup. A guard shown here is stored evidence, not a freshly observed guard.
Focus cannot be combined with `--json`; omitted focus preserves prior output.
For full JSON, use `show --json`; for original captured bytes, use `evidence`.
Neither reader replays the original operation or restores spent admission.

Stop after that first inspection. Only after explicitly accepting the physical
scope, choose a distinct scope intent and absent second-result file:

```bash
: "${aware_scope_intent:?Choose a new explicit scope decision intent}"
: "${aware_second_result:?Choose an absent private second-result JSON file}"
test ! -e "$aware_second_result"
test ! -L "$aware_second_result"
set -C
"$AWARE" workspace review scope --repository-root "$aware_customer_repo" --evidence-root "$aware_evidence_root" --reference-from-stdin --client-intent-id "$aware_scope_intent" --accept-reviewed-effect-scope --json < "$aware_first_result" > "$aware_second_result"
```

Stop again and inspect this second result and its complete evidence. Inspect its
final files with `show --focus files`, consuming **that second result**, not the
first. Scope acceptance does not authorize apply. Only after a separate final-file
decision invoke apply with its own intent:

```bash
: "${aware_apply_intent:?Choose a new explicit apply decision intent}"
"$AWARE" workspace review apply --repository-root "$aware_customer_repo" --evidence-root "$aware_evidence_root" --reference-from-stdin --client-intent-id "$aware_apply_intent" --accept-reviewed-final-files --json < "$aware_second_result"
```

Do not pipe prepare directly into scope/apply as an unattended sequence. Do not
blindly run these blocks in sequence. Fresh owner currentness checks still use
the original reviewed guards unchanged. Staleness requires a new explicit prepare
and review decision, never automatic refresh. Spent reuse remains refused and
may report genuine exit-3 retention/cleanup incompleteness. Workspace reference
transport does not automate Issue guard extraction, publication or closeout.

## Carry a reviewed Issue observation without extracting its guard

Use an Issue to coordinate bounded customer work; add a SPEC draft when shared
intent needs one. Finish and test the useful implementation before publication.
CLI 0.8.4 can carry a full reviewed Issue observation into the original
`bind-scope`, `start-progress` and `publish-close` commands. It removes manual
digest extraction at those entrances, not the need to review or decide.

Begin with an existing Issue created through the installed owner's first-Issue
workflow, owned by your genuine execution. Select the customer repository,
canonical Issue reference, exact Markdown path, actor/evidence and implementation
paths explicitly. The acquired contributor checkout is not the customer target.
Choose private observation/capture files outside the publication scope.

Capture exactly one full original read result into a new file. The read takes
repository/Issue coordinates, not mutation actor flags:

```bash
: "${aware_customer_repo:?Set the absolute customer repository}"
: "${aware_issue_ref:?Set the approved fb/YYYY-MM-DD/slug reference}"
: "${aware_issue_observation:?Choose an absent private observation file}"
test ! -e "$aware_issue_observation"
test ! -L "$aware_issue_observation"
set -C
"$AWARE" issue resolve-read-projection --repository-root "$aware_customer_repo" --issue-ref "$aware_issue_ref" --format json > "$aware_issue_observation"
```

Stop and read that saved result. Require `outcome="found"`, the intended Issue
and source coordinate, and the expected owner. A read does not admit mutation.
The detached frame does not authenticate its capture origin or repository.
A filename, Markdown, mutation result, summary or handcrafted digest envelope
is not a substitute for the full original result.

Only after reviewing the intended exact scope, select the original observation
through stdin. The scope includes the Issue document and intended implementation
file; add every other actually intended path explicitly before mutation:

```bash
: "${aware_issue_path:?Set the exact repository-relative Issue Markdown path}"
: "${aware_implementation_path:?Set the reviewed exact implementation file}"
: "${aware_actor_ref:?Use the genuine provider execution}"
: "${aware_actor_evidence:?Use accepted actor evidence}"
: "${aware_scope_intent:?Choose a distinct explicit scope intent}"
"$AWARE" issue bind-scope --repository-root "$aware_customer_repo" --issue-ref "$aware_issue_ref" --actor-ref "$aware_actor_ref" --actor-evidence-ref "$aware_actor_evidence" --client-intent-id "$aware_scope_intent" --scope-path "$aware_issue_path" --scope-path "$aware_implementation_path" --issue-observation-from-stdin --format json < "$aware_issue_observation"
```

Scope mutation changes Issue bytes. Do not reuse its earlier observation to start
progress. Capture and review a fresh full read in a different absent private
file using the first block, then explicitly decide to start:

```bash
: "${aware_progress_intent:?Choose a distinct explicit progress intent}"
"$AWARE" issue start-progress --repository-root "$aware_customer_repo" --issue-ref "$aware_issue_ref" --actor-ref "$aware_actor_ref" --actor-evidence-ref "$aware_actor_evidence" --client-intent-id "$aware_progress_intent" --issue-observation-from-stdin --format json < "$aware_issue_observation"
```

Do the admitted work and its tests. Before publication, finish Issue updates,
capture another fresh full observation into a different absent private file, and
review the implementation and complete admitted scope. Choose the publication
message, resolution, verification evidence and intent explicitly. Preview only:

```bash
: "${aware_publication_intent:?Choose the explicit publication intent}"
: "${aware_publication_message:?Set the reviewed implementation message}"
: "${aware_resolution:?Describe the supported completed outcome}"
: "${aware_verified_by:?Set retained verification evidence}"
"$AWARE" issue publish-close --repository-root "$aware_customer_repo" --issue-ref "$aware_issue_ref" --actor-ref "$aware_actor_ref" --actor-evidence-ref "$aware_actor_evidence" --client-intent-id "$aware_publication_intent" --path "$aware_issue_path" --path "$aware_implementation_path" --message "$aware_publication_message" --resolution "$aware_resolution" --verified-by "$aware_verified_by" --issue-observation-from-stdin --format json --dry-run < "$aware_issue_observation"
```

Stop and review the preview and intervening work. After a separate apply decision,
repeat that exact request and the same saved observation, removing only
`--dry-run`. Do not execute preview and apply as an unattended pipe.

**Apply plans afresh.** Carrying the same observation preserves its exact Issue
digest and explicit arguments; it does not bind apply to previewed HEAD or source
bytes. Intervening implementation changes can be included by fresh planning.
This input is not a preview-byte freeze. Preserve original owner refusals; never
silently replace the Issue guard, fabricate a reference or retry. Publication
and Issue closeout are two non-atomic owner operations in one invocation.
Retain complete original output on refusal as well as success; do not replay a
mutation to recover its receipts or regain completion authority.

Select exactly one guard source: `--issue-observation-from-stdin` or the
command's existing direct digest flag, never both. Direct-guard compatibility
remains available. Source paths inside the frame are evidence, not selectors
for a repository or admitted scope.

Issue stdin is bounded to **786432 raw bytes**, strict UTF-8, one integer-only
JSON object and EOF, with duplicate-key and depth/node/array/string limits.
These are not Workspace's separate 2 MiB reference-frame limits. Input and typed
request validation happen before provider acquisition. Local input refusal is
exit 2 with `provider_invoked=false` and `effect=none`; interruption is 130.
Failed output reporting remains 3, or preserves an already selected 130, without
resending the failed buffer or repeating provider work. Post-dispatch failures
retain original evidence; they must not be relabelled as input refusal with no
effects. Summary and full owner outputs retain their original meanings.

## Refusal, retention and cleanup are independent

Read the primary owner code and reason first. Then inspect evidence retention
and client cleanup separately. This successor's clean stale Issue and authority
source refusals retain a typed original refusal with published/complete evidence
and exit **2**. `product_dispatch=not_invoked` refers only to that refused action;
it does not deny prior effects, observations, scope changes or evidence writes.
A saved refusal is evidence only, not a review, admission or restored authority.

Do not infer that every refusal exits 2. Spent-reference incompleteness in this
qualified composition remains exit **3**, without additional manifest effects.
Unknown/incomplete current retention, failed client cleanup or unavailable
projection/output preserve genuine incompleteness. Original release unknown
does not by itself determine the current exit: the qualified successful apply
returns 0 while retaining that original unknown. Interruption remains **130**,
including combined interruption/output failure.
Exit **0** reports that command's completion, not approval of another operation.
An already completed effect may coexist with exit 3 or 130. Do not replay apply
to obtain a cleaner receipt or to regain authority.

Human summaries answer five questions: **What happened**, **What changed**,
**What remains uncertain**, **What next (guidance, not authority)** and
**Where is full evidence**. They distinguish final files, physical scope,
original admission, release/retention and client cleanup. JSON preserves original
owner values. The original Issue scope mutation outcome is separate from scope
evidence retention and manifest apply. Successful scope binding stays applied
even if subsequent capture fails; do not repeat scope to manufacture evidence.

`show` accepts historical review records only; it is not a generic receipt
reader and grants no current-use authority. For retained refusals, outcomes or
other supported evidence kinds use `evidence`, with the same explicit roots and
exact SDK-issued reference. The reference container kind is not necessarily the
schema of the captured command bytes. If no SDK reference was returned, retain
available full JSON and original evidence; do not invent one or redispatch.
An incomplete capture may return a reference to earlier evidence, not proof of a
complete current failure capture.
`review evidence` returns exact original retained UTF-8 bytes with independent
cleanup on stderr; it does not replay the operation. Missing or incomplete
captures expose available evidence, not a synthetic concise success.

Original unknown release stays **unknown** after successful later client cleanup.
Output failure never authorizes redispatch. Preserve known publication, partial
effects and uncertainty before a separately supported recovery decision.
Repository publication and paired Issue closeout remain separate original owner
operations; reviewed setup neither commits customer files nor closes the Issue.

## Read returned resource releases without completing ledgers

Human summaries now show **Private evidence directory release** beside its
**family ledger complete** value, and **Original failed-sequence release**
beside its **sequence ledger complete** value. These are separate original
owner observations. A returned `confirmed` release describes that resource
only; it does not establish complete evidence retention, composite client
cleanup or historical Workspace completion. Missing release or ledger rows
stay **unknown/not returned**.

For example, a private evidence directory may report confirmed release while
its family ledger remains incomplete and the command exits 3. The original
Workspace release can remain unknown even after later resource closes. Preserve
both facts; neither grants permission to repeat scope/apply. Full JSON and
original exits remain unchanged. Use the original `show` or `evidence` reader
appropriate to the returned reference kind rather than replaying the operation.

## Source and notice boundaries

`SOURCE-INDEX.json` binds **1,374 selected source files**, including 1,365
whole-package members, with original revisions, effective digests and executable
modes. Three Workspace manifests use explicit reviewed metadata-only overlays
on the historical implementation source, not version fields already present in
that historical revision. `source-bindings/workspace-metadata-overlays.json`
binds each original preimage, effective manifest and immutable freeze coordinate;
the original manifests are retained under `source-bindings/original-metadata/`.
All other source bodies remain exact Git bytes. The catalog revision is not a
single-source-revision claim. All 28 complete Aware package trees are present
without hand pruning, dirty implementation overlays or later observer/continuation
code.
Full discovery inventory remains producer-side; delivery pointers and indexes
are evidence, not a second package catalog. Customer `aware.protocol.toml`
configures protocol records, not Python package selection.

All fourteen third-party wheels and inherited source/legal/build inputs remain
unchanged. Current notice bindings correlate these attachments to current wheel
identities. Six package-local legal gaps remain unrepaired: this is whole-envelope
delivery only, not detached-wheel acceptance. Earlier notice/disclosure decisions
do not automatically transfer to this envelope. Source-derived jsonschema retains
its recipe, constraints and publisher source URL/hash, not its original archive.

The Workspace native payload has a separate exact binary account, original C
source/stub/build hook/metadata and dynamic-reference inspection. This is not an
independent rebuild, exact static-linkage proof, complete toolchain/header chain
or broader native performance/capability acceptance. The inherited PSF-chain
attachment does not prove the actual header/toolchain provenance. Shared SDK/Meta
infrastructure does not admit object/materialization or Service/API operations.

`CONTENT-AUDIT.json` reruns seven bounded byte patterns across source, binaries
and attached archives. Findings and historical audits remain visible;
`clearance=not_granted` is not overwritten. No bounded scan proves exhaustive
disclosure or notice sufficiency. Independent technical review and exact-envelope
notice/disclosure decisions must precede public layout or delivery.
