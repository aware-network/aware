# Aware reviewed Workspace A1 workflow

Draft technical-review instructions for one exact Linux x86-64 / Python 3.12
installation. Agent 0.2.0a7 composes Workspace SDK 0.2.10, Runtime 0.2.15 and
FS adapter 0.1.9 with FileSystem 0.3.8 and Issue SDK 0.10.6. All 42 packages
come from the canonical `portable_protocols` selection. This envelope changes
presentation and source/notice attachments, not the accepted software.

The bounded installed proof covers repository-manifest A1 through two explicit
reviews and apply. It does not qualify the historical 2,819-case aggregate,
broader carried features, A2, tree completion or unassisted onboarding.
Notice/disclosure decisions, instruction freeze and publication remain pending.

## Install with all source and notice attachments

Keep this complete envelope with the installation. Verify outer `SHA256SUMS`,
then expand `payload/aware-canonical-neutral-fs-internal-v1.tar.gz` into a fresh
private directory. Verify the inner `SHA256SUMS`. Do not acquire detached wheels
or strip the source/legal attachments. Select an absent environment under an
existing private parent and invoke the shipped installer from the expanded
inner payload directory:

```bash
set -eu
: "${aware_review_env:?Set an absolute absent environment under a private parent}"
test ! -e "$aware_review_env"
test ! -L "$aware_review_env"
PYTHON_BIN=/usr/bin/python3.12 /bin/sh ./install.sh "$aware_review_env"
AWARE="$aware_review_env/bin/aware"
"$AWARE" --help
"$AWARE" init --help
"$AWARE" workspace review --help
```

Installing tooling, preparing configuration and obtaining admission are distinct
steps. `aware init` previews by default; explicit creation/apply invokes
Workspace preparation followed by fresh Protocol bootstrap admission. A
new-repository preview contains a Workspace preparation preview and prospective
Protocol inputs, not two admitted owner plans. Init supplies the Protocol
configuration used by this qualified fresh-repository workflow. It does not
admit an Issue, approve scope or authorize Workspace apply. It also does not
stage files, commit or select a remote.

Use this one installation's original Issue, Protocol and SPEC registrars.
Existing first-Issue, setup and draft operations remain carried; historical
source READMEs are not alternative customer instructions. No contributor a6
command selection or bootstrap is replaced here.

## Prepare the admitted A1 inputs

The reviewed command currently creates a repository manifest. It requires an
explicit repository, admitted Issue reference **and** exact Issue Markdown
path, existing Protocol configuration, declared actor and evidence coordinates,
approved repository name/license expression and unique
client intent. An Issue reference is not its Markdown filename. Read installed
help and the original owner diagnostics rather than guessing its syntax.
This qualified fresh-repository journey uses init-created `aware.protocol.toml`
directly, without another configuration step. Genuine admission is obtained
through the Issue/review/apply operations, not by the configuration alone.

The private evidence root must already exist, outside and disjoint from the
repository. Do not use a shared evidence root, synthesize records or handwrite
SDK references. Preparation observes current owner inputs and retains their
evidence; it grants no setup write admission and performs no Issue scope change.
If owner configuration or Issue inputs are missing, stop rather than inventing
them or bypassing the governed route.

```bash
"$AWARE" workspace review prepare --help
"$AWARE" workspace review show --help
"$AWARE" workspace review scope --help
"$AWARE" workspace review apply --help
"$AWARE" workspace review evidence --help
```

## Two distinct review decisions

First invoke `review prepare` with the explicit owner inputs. Review its
repository, Issue, authority source, requested manifest, complete physical
effect scope, proposed final files and current cleanup. Physical scope includes
temporary effects; it is not interchangeable with the final-file set.

Only after accepting that physical scope invoke `review scope` with
`--accept-reviewed-effect-scope` and the exact SDK-issued first reference.
The original Issue SDK binds the scope, preserving previously admitted work;
the original Workspace SDK retains that outcome and produces the second
preview. Review that second preview and its final files separately. Scope
acceptance does not authorize automatic apply.

Only after that second decision invoke `review apply` with
`--accept-reviewed-final-files` and the exact second reference. Keep the same
explicit repository/evidence root. Each mutation needs its own explicit intent.
The installed handlers use original SDK guards unchanged; the client does not
copy guards, reconstruct record files or calculate a replacement allowlist.

`--reference` is the complete opaque SDK-issued `SetupEvidenceRef` JSON value,
not a JSON file path or a new package catalog. Reuse the returned value exactly;
do not author its fields, execute JSON vectors or use `eval`. Use `show --json`
for the full owner record when a summary omits a long path set. Retain both
review references and the original evidence for handoff.

Stale, spent, malformed or foreign current-use requests stop. Prepare and review
again only after an explicit new decision; never silently refresh guards or
retry a mutation. Historical inspection through `show` grants no current-use
authority. Scope success followed by second-preview failure remains scope
success with a later failure, not rollback. Preserve that original outcome.

## Read effects and cleanup independently

Human summaries distinguish final files, complete physical scope, original
admission/release state and client cleanup. `review evidence` returns the exact
retained original UTF-8 capture, with independent client cleanup on stderr;
reading evidence does not repeat the operation. JSON preserves full SDK values.
Exit 0 means that command completed, 2 is refusal, 3 is incomplete output or
cleanup, and 130 is interruption. A completed effect can coexist with exit 3.

Original unknown release outcomes remain unknown after successful later client
cleanup. Incomplete retention exposes available full evidence instead of a
concise success. Output failure must not cause redispatch. Preserve successful,
partial and unknown effects before choosing a separately supported recovery.
Repository commit and paired Issue closeout remain separate owner operations;
this reviewed setup neither commits customer files nor closes the Issue.

## Exact composite sources and notice coverage

`SOURCE-INDEX.json` binds 1,329 committed selected files, with each original Git
revision, digest and mode. Its catalog revision is not a claim that every
supplier came from one revision. Complete package trees and exact Workspace
metadata overlays remain present. Full discovery inventory stays producer-side;
the index and delivery coordinates are evidence, not another software selector.
Customer `aware.protocol.toml` configures protocol records, not Python packages.

Keep LICENSE, NOTICE, `source/THIRD_PARTY_NOTICES.md`, all source archives,
component evidence and indexes with the payload. Six package-local legal gaps
remain unrepaired. This engineering delivery requires the whole envelope;
detached wheels, stripped bundles and registry publication remain unaccepted.

All third-party wheels are unchanged from the predecessor. Current bindings
retain its source archives, MPL corresponding source, schema attribution,
complete license alternatives and conservative native-component notices. The
source-derived jsonschema recipe/constraints and publisher source URL/hash
remain attached; its original source archive is not attached. Original indexes
under `historical/` retain their earlier identities, not current clearance.

The carried Workspace native formatter is correlated to its original C source,
stub, build hook, metadata and exact binary. Dynamic-reference inspection is not
an independent rebuild, exact static-linkage proof, complete toolchain/header
account or acceptance of broader native behavior/performance. Shared SDK/Meta
libraries and retained Workspace planning code do not admit materialization,
object operations, Service/API, A2 or tree completion.

`CONTENT-AUDIT.json` reruns the bounded seven-pattern scan, including binary
bytes and attached source archives. All findings remain visible; the previous
audit is retained separately. No negative scan proves exhaustive disclosure or
legal sufficiency. Independent technical review and exact-envelope owner
notice/disclosure decisions must precede public layout or delivery.
