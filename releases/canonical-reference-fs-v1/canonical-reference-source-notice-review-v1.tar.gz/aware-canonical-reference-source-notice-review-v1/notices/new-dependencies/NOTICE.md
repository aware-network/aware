# A1 candidate dependency inputs

These source/legal inputs bind the seven changed third-party wheels, not a new
package selection. The previous notice indexes remain historical evidence.
Pathspec's unchanged MPL source/terms and PyYAML's unchanged conservative build
inputs remain attached under historical/. Current pydantic-core/rpds Cargo inputs
support an explicit component-coverage review; inherited crate notices are not
an attestation of this binary's exact static linkage. The source-correlated
Cython terms do not establish the wheel publisher's toolchain. Notice sufficiency
and public disclosure remain pending for the complete resulting envelope.
